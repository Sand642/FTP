package com.runner;


import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import com.baseclass.BaseClass;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = {
		

		"D:\\Project\\RMS\\src\\test\\java\\com\\feature\\DownloadFile.feature"
	
},
        glue = {"com.stepdefinition"},
        dryRun = false,
		//tags="@New",
		plugin = { "pretty", 
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
				"html:target/HtmlReports1/report.html", "json:target/JSONReports/report.json",
				"junit:target/JUnitReports/report.xml" }
                  )


public class Runner {

	public static WebDriver driver;

	@SuppressWarnings("deprecation")
	@BeforeClass
	public static void browserLaunch() {

		driver = BaseClass.launchBroswer("Chrome");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
}
