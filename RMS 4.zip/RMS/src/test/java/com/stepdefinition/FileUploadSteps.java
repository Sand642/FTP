package com.stepdefinition;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.ftp.FTPSClient;

import io.cucumber.java.en.Then;

public class FileUploadSteps {

	@Then("upload all MCX files to FTP server")
	public void upload_all_mcx_files_to_ftp_server() {
        String filePath = "D:\\Project\\RMS\\MCX_Files\\File1\\Bhavcopy.csv";
        File file = new File(filePath);

        if (!file.exists() || !file.isFile()) {
            System.out.println("File does not exist or is not a file: " + filePath);
            return;
        }

        String server = "103.217.66.206";
        int port = 65500;
        String username = "navia";
        String password = "Navia@#6754";

        FTPSClient ftpClient = new FTPSClient();
        try {
            System.out.println("Connecting to FTP server...");
            ftpClient.setUseClientMode(true);
            ftpClient.connect(server, port);
            ftpClient.setSoTimeout(120000); // Set timeout to 120 seconds
            System.out.println("Connected to FTP server.");

            if (!ftpClient.login(username, password)) {
                System.out.println("Login failed.");
                return;
            }
            System.out.println("Login successful.");

            ftpClient.execPBSZ(0);
            ftpClient.execPROT("P");
            ftpClient.enterLocalPassiveMode();

            if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
                System.out.println("FTP reply not positive, aborting upload.");
                return;
            }

            try (FileInputStream fis = new FileInputStream(file)) {
                System.out.println("Uploading file: " + file.getName());
                boolean uploaded = ftpClient.storeFile(file.getName(), fis);
                if (uploaded) {
                    System.out.println("File uploaded successfully.");
                } else {
                    System.out.println("Failed to upload file.");
                    System.out.println("FTP reply code: " + ftpClient.getReplyCode());
                    System.out.println("FTP reply string: " + ftpClient.getReplyString());
                }
            }

        } catch (IOException e) {
            System.out.println("IOException during FTP operation: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (ftpClient.isConnected()) {
                    ftpClient.logout();
                    ftpClient.disconnect();
                    System.out.println("Disconnected from FTP server.");
                }
            } catch (IOException ex) {
                System.out.println("Error disconnecting from FTP server: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }
}
