package com.stepdefinition;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.baseclass.BaseClass;

import atu.testrecorder.ATUTestRecorder;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MCX_Files extends BaseClass {

	public static ATUTestRecorder recorder;

	@Before
	public static void beforeStartTestCase() throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH-mm-ss");
		Date date = new Date();
		recorder = new ATUTestRecorder("D:\\Project\\RMS\\Video", "RecordedVideo-" + dateFormat.format(date), false);
		recorder.start();

	}
	
	 

	@After
	public static void afterTestCase() throws Exception {

		recorder.stop();

		//driver.manage().deleteAllCookies();

	}

	@Given("User Launch The Url")
	public void user_launch_the_url() throws InterruptedException {

		driver.get("https://sftp.mcxindia.com/");
		Thread.sleep(2000);

	}

	@When("User Send The {string} Login ID")
	public void user_send_the_login_id(String string) throws InterruptedException {

		try {

			driver.findElement(By.xpath("//input[@name='user']")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@name='user']")).sendKeys(string);
			Thread.sleep(3000);

		} catch (Exception e) {

			System.out.println("Network Issue");
		}

	}

	@When("User Send The {string} Password")
	public void user_send_the_password(String string) throws InterruptedException {

		try {

			driver.findElement(By.xpath("//input[@name='pword']")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@name='pword']")).sendKeys(string);
			Thread.sleep(3000);

		} catch (Exception e) {

			System.out.println("Network Issue");
		}

	}

	@When("User Click The Login button")
	public void user_click_the_login_button() throws InterruptedException {

		try {

			Thread.sleep(2000);
			driver.findElement(By.xpath("//button[@id='btn-LoginButton']")).click();
			Thread.sleep(4000);

		} catch (Exception e) {

			System.out.println("Invalid Your Login ID");
		}

	}

	@When("User Navigate Home Page")
	public void user_navigate_home_page() throws InterruptedException {

		try {

			Thread.sleep(2000);
			driver.navigate().to("https://sftp.mcxindia.com/Web%20Client/ListDir.htm");// https://sftp.mcxindia.com/Web%20Client/ListDir.htm
			Thread.sleep(3000);

		} catch (Exception e) {

			System.out.println("Network Issue");

		}

	}

	@When("User Mouse Over and Click the {string} Folder")
	public void user_mouse_over_and_click_the_folder(String string) throws InterruptedException {

		try {

			Thread.sleep(2000);

			WebElement element = driver.findElement(By.xpath("(//span[text()='" + string + "']//parent::span)[1]"));
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", element);
			Thread.sleep(2000);

			WebElement element2 = driver.findElement(By.xpath("(//span[text()='" + string + "']//parent::span)[1]"));
			Actions a = new Actions(driver);

//			assert element2.isDisplayed();		
//			a.moveToElement(element2).perform();
			Thread.sleep(2000);

			element2.click();
			element2.click();
			Thread.sleep(1000);
			a.doubleClick(element2).perform();

			Thread.sleep(3000);

		} catch (Exception e) {

			System.out.println("Network Issue");

		}

	}

	@When("User Click The {string} Folder")
	public void user_click_the_folder(String string) throws InterruptedException, AWTException {

		try {
			Thread.sleep(2000);

			WebElement element = driver.findElement(By.xpath("//span[text()='" + string + "']"));
			Thread.sleep(2000);
			Actions a = new Actions(driver);

			element.click();
			Thread.sleep(2000);

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			Thread.sleep(2000);

			a.doubleClick(element).perform();

			Thread.sleep(3000);

		} catch (Exception e) {

			System.out.println("Network Issue");

		}

	}

	@When("User Download the {string} Current File")
	public static void user_download_the_current_file(String string) throws InterruptedException, AWTException {

		try {

			LocalDate currentDate = LocalDate.now();

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
			String date = currentDate.format(formatter);
			String g = "\u001B[35m";
			System.out.println(g+date);

			WebElement element = driver.findElement(
					By.xpath("((//span[text()='" + string + "']//ancestor::span)[9]//following-sibling::span)[5]"));
			String text = element.getText();
			System.out.println(text);

			// Step 3: Parse input string to LocalDate
			LocalDate originalDate = LocalDate.parse(date, formatter);

			// Step 4: Subtract 2 days
			LocalDate updatedDate = originalDate.minusDays(2);
			String last = updatedDate.format(formatter);

			if (text.contains(date)) {

				WebElement element1 = driver.findElement(By.xpath("//span[text()='" + string + "']"));

				Actions a = new Actions(driver);

				element1.click();
				Thread.sleep(2000);

				Robot robot = new Robot();

				robot.keyPress(KeyEvent.VK_DOWN);
				robot.keyRelease(KeyEvent.VK_DOWN);
				Thread.sleep(2000);

				a.doubleClick(element).perform();

				Thread.sleep(2000);
				//System.err.println("The File is successfully Downloading");

			}

			else if (text.contains(last)) {

				WebElement element1 = driver.findElement(By.xpath("//span[text()='" + string + "']"));

				Actions a = new Actions(driver);

				element1.click();
				Thread.sleep(2000);

				Robot robot = new Robot();

				robot.keyPress(KeyEvent.VK_DOWN);
				robot.keyRelease(KeyEvent.VK_DOWN);
				Thread.sleep(2000);

				a.doubleClick(element).perform();
				System.out.println(last);

			}

			else {

				System.err.println("Today Not Upload File");

			}

		} catch (Exception e) {

			System.out.println("Network Issue");

		}

	}

	@Then("User Save The {string} File Location")
	public void user_save_the_file_location(String string) throws InterruptedException, AWTException {

		Thread.sleep(3000);

		switch (string) {

		case "Bhavcopy":

			StringSelection s1 = new StringSelection("D:\\Project\\RMS\\MCX_Files\\File1");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s1, null);

			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			Thread.sleep(1000);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(1000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

			Thread.sleep(1000);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);

			robot.keyPress(KeyEvent.VK_LEFT);
			robot.keyRelease(KeyEvent.VK_LEFT);
			Thread.sleep(1000);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);

           WebElement element6 = driver.findElement(By.xpath("//div[@id='container']"));
			
			if (element6.isDisplayed()) {
				String g = "\u001B[35m";
				System.out.println(g+"The File is successfully Downloading");
				
			} else {
				
				driver.close();

			}


			break;

		case "MCXScrips":

			StringSelection s2 = new StringSelection("D:\\Project\\RMS\\MCX_Files\\File2");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s2, null);

			Robot robot2 = new Robot();
			robot2.keyPress(KeyEvent.VK_CONTROL);
			robot2.keyPress(KeyEvent.VK_V);
			Thread.sleep(1000);
			robot2.keyRelease(KeyEvent.VK_V);
			robot2.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(1000);
			robot2.keyPress(KeyEvent.VK_ENTER);
			robot2.keyRelease(KeyEvent.VK_ENTER);

			Thread.sleep(1000);

			robot2.keyPress(KeyEvent.VK_ENTER);
			robot2.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);

			robot2.keyPress(KeyEvent.VK_LEFT);
			robot2.keyRelease(KeyEvent.VK_LEFT);
			Thread.sleep(1000);

			robot2.keyPress(KeyEvent.VK_ENTER);
			robot2.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);

           WebElement element5 = driver.findElement(By.xpath("//div[@id='container']"));
			
			if (element5.isDisplayed()) {
				String g = "\u001B[35m";
				System.out.println(g+"The File is successfully Downloading");
				
			} else {
				
				driver.close();

			}


			break;

		case "Margin":

			StringSelection s3 = new StringSelection("D:\\Project\\RMS\\MCX_Files\\File3");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s3, null);

			Robot robot3 = new Robot();
			robot3.keyPress(KeyEvent.VK_CONTROL);
			robot3.keyPress(KeyEvent.VK_V);
			Thread.sleep(1000);
			
			robot3.keyRelease(KeyEvent.VK_V);
			robot3.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(1000);
			robot3.keyPress(KeyEvent.VK_ENTER);
			robot3.keyRelease(KeyEvent.VK_ENTER);

			Thread.sleep(3000);
			
//			robot3.keyPress(KeyEvent.VK_TAB);
//			robot3.keyRelease(KeyEvent.VK_TAB);
//			Thread.sleep(3000);
			
			Robot robot1 = new Robot();
			robot1.setAutoDelay(100);  // delay between keypress and release
			
			 String command2 = "MarginDetailReport";
	            StringSelection selection2 = new StringSelection(command2);
	            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection2, null);

	            Thread.sleep(1000); // Wait 1 sec to ensure clipboard is ready

	            // 2. Press Ctrl + V (Paste)
	            robot1.keyPress(KeyEvent.VK_CONTROL);
	            robot1.keyPress(KeyEvent.VK_V);
	            robot1.keyRelease(KeyEvent.VK_V);
	            robot1.keyRelease(KeyEvent.VK_CONTROL);

	            Thread.sleep(2000); // Small delay


			Thread.sleep(1000);

			robot3.keyPress(KeyEvent.VK_ENTER);
			robot3.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);

			robot3.keyPress(KeyEvent.VK_LEFT);
			robot3.keyRelease(KeyEvent.VK_LEFT);
			Thread.sleep(1000);

			robot3.keyPress(KeyEvent.VK_ENTER);
			robot3.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			
			WebElement element = driver.findElement(By.xpath("//div[@id='container']"));
			
			if (element.isDisplayed()) {
				String g = "\u001B[35m";
				System.out.println(g+"The File is successfully Downloading");
				
			} else {
				
				driver.close();

			}

			

			break;

		case "Bhavcopy_MCX":

			StringSelection s41 = new StringSelection("D:\\Project\\RMS\\MCX_Files\\File4");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s41, null);

			Robot robot4 = new Robot();
			robot4.keyPress(KeyEvent.VK_CONTROL);
			robot4.keyPress(KeyEvent.VK_V);
			Thread.sleep(1000);
			robot4.keyRelease(KeyEvent.VK_V);
			robot4.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(1000);
			robot4.keyPress(KeyEvent.VK_ENTER);
			robot4.keyRelease(KeyEvent.VK_ENTER);

			Thread.sleep(3000);
			
//			robot4.keyPress(KeyEvent.VK_TAB);
//			robot4.keyRelease(KeyEvent.VK_TAB);
//			Thread.sleep(3000);
			
			Robot robot11 = new Robot();
			robot11.setAutoDelay(100);  // delay between keypress and release

			//String text1 = "BhavcopyMCX";
			Thread.sleep(2000);
			    String command21 = "BhavcopyMCX";
	            StringSelection selection21 = new StringSelection(command21);
	            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection21, null);

	            Thread.sleep(1000); // Wait 1 sec to ensure clipboard is ready

	            // 2. Press Ctrl + V (Paste)
	            robot11.keyPress(KeyEvent.VK_CONTROL);
	            robot11.keyPress(KeyEvent.VK_V);
	            robot11.keyRelease(KeyEvent.VK_V);
	            robot11.keyRelease(KeyEvent.VK_CONTROL);

	            Thread.sleep(2000); // Small delay

			robot4.keyPress(KeyEvent.VK_ENTER);
			robot4.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);

			robot4.keyPress(KeyEvent.VK_LEFT);
			robot4.keyRelease(KeyEvent.VK_LEFT);
			Thread.sleep(1000);

			robot4.keyPress(KeyEvent.VK_ENTER);
			robot4.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);

        WebElement element1 = driver.findElement(By.xpath("//div[@id='container']"));
			
			if (element1.isDisplayed()) {
				String g = "\u001B[35m";
				System.out.println(g+"The File is successfully Downloading");
				
			} else {
				
				driver.close();

			}


			break;

		case "MCXRPF":

			StringSelection s5 = new StringSelection("D:\\Project\\RMS\\MCX_Files\\File5");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s5, null);

			Robot robot5 = new Robot();
			robot5.keyPress(KeyEvent.VK_CONTROL);
			robot5.keyPress(KeyEvent.VK_V);
			Thread.sleep(1000);
			robot5.keyRelease(KeyEvent.VK_V);
			robot5.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(1000);
			robot5.keyPress(KeyEvent.VK_ENTER);
			robot5.keyRelease(KeyEvent.VK_ENTER);

			Thread.sleep(3000);
			
//			robot5.keyPress(KeyEvent.VK_TAB);
//			robot5.keyRelease(KeyEvent.VK_TAB);
//			Thread.sleep(3000);
			
			Robot robot111 = new Robot();
			robot111.setAutoDelay(100);  // delay between keypress and release

			String command211 = "MCXRPF";
            StringSelection selection211 = new StringSelection(command211);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection211, null);

            Thread.sleep(1000); // Wait 1 sec to ensure clipboard is ready

            // 2. Press Ctrl + V (Paste)
            robot111.keyPress(KeyEvent.VK_CONTROL);
            robot111.keyPress(KeyEvent.VK_V);
            robot111.keyRelease(KeyEvent.VK_V);
            robot111.keyRelease(KeyEvent.VK_CONTROL);

            Thread.sleep(2000); // Small delay

			robot5.keyPress(KeyEvent.VK_ENTER);
			robot5.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);

			robot5.keyPress(KeyEvent.VK_LEFT);
			robot5.keyRelease(KeyEvent.VK_LEFT);
			Thread.sleep(1000);

			robot5.keyPress(KeyEvent.VK_ENTER);
			robot5.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);

          WebElement element2 = driver.findElement(By.xpath("//div[@id='container']"));
			
			if (element2.isDisplayed()) {
				String g = "\u001B[35m";
				System.out.println(g+"The File is successfully Downloading");
				
			} else {
				
				driver.close();

			}


			break;

		case "MCX_ProductMaster":

			StringSelection s6 = new StringSelection("D:\\Project\\RMS\\MCX_Files\\File6");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s6, null);

			Robot robot6 = new Robot();
			robot6.keyPress(KeyEvent.VK_CONTROL);
			robot6.keyPress(KeyEvent.VK_V);
			Thread.sleep(1000);
			robot6.keyRelease(KeyEvent.VK_V);
			robot6.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(1000);
			robot6.keyPress(KeyEvent.VK_ENTER);
			robot6.keyRelease(KeyEvent.VK_ENTER);

			Thread.sleep(1000);

			robot6.keyPress(KeyEvent.VK_ENTER);
			robot6.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);

			robot6.keyPress(KeyEvent.VK_LEFT);
			robot6.keyRelease(KeyEvent.VK_LEFT);
			Thread.sleep(1000);

			robot6.keyPress(KeyEvent.VK_ENTER);
			robot6.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);

         WebElement element3 = driver.findElement(By.xpath("//div[@id='container']"));
			
			if (element3.isDisplayed()) {
				String g = "\u001B[35m";
				System.out.println(g+"The File is successfully Downloading");
				
			} else {
				
				driver.close();

			}


			break;

		default:
			
			System.err.println("Invalid Your MCX FILE");
			
			break;
		}

	}

	@Then("Next Page Shown")
	public void next_page_shown() throws InterruptedException {

		try {

			String title = driver.getTitle();
			System.out.println(title);
			Thread.sleep(2000);
			String yellow = "\u001B[33m";
			System.out.println(yellow+"**************************************************************************");

		} catch (Exception e) {

			System.err.println("Some Issue");
			Thread.sleep(2000);

		}

	}

	@When("User Mouse Over and Click the Year Folder")
	public void user_mouse_over_and_click_the_year_folder() throws InterruptedException {

		try {

			Thread.sleep(2000);

			LocalDate currentDate = LocalDate.now();

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy");
			String date = currentDate.format(formatter);
			String g = "\u001B[35m";
			System.out.println(g+date);

			WebElement element = driver.findElement(By.xpath("(//span[text()='" + date + "']//parent::span)[1]"));
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", element);
			Thread.sleep(2000);

			WebElement element2 = driver.findElement(By.xpath("(//span[text()='" + date + "']//parent::span)[1]"));
			Actions a = new Actions(driver);

			Thread.sleep(2000);

			element2.click();
			element2.click();
			Thread.sleep(1000);
			a.doubleClick(element2).perform();

			Thread.sleep(3000);
		} catch (Exception e) {

			System.err.println("Network Issue");
		}

	}

	@When("User Mouse Over and Click the Month Folder")
	public void user_mouse_over_and_click_the_month_folder() throws InterruptedException {

		//try {

			Thread.sleep(2000);

//			LocalDate currentDate = LocalDate.now();
//
//			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM");
//			String month = currentDate.format(formatter);
//			String g = "\u001B[35m";
//			System.out.println(g+month);
//
//			WebElement element = driver.findElement(By.xpath("(//span[text()='" + month + "']//parent::span)[1]"));
//			Thread.sleep(2000);
//			JavascriptExecutor js = (JavascriptExecutor) driver;
//			js.executeScript("arguments[0].scrollIntoView();", element);
//			Thread.sleep(2000);
//
//			WebElement element2 = driver.findElement(By.xpath("(//span[text()='" + month + "']//parent::span)[1]"));
//			Actions a = new Actions(driver);
//
//			Thread.sleep(2000);
//
//			element2.click();
//			element2.click();
//			Thread.sleep(1000);
//			a.doubleClick(element2).perform();
//
//			Thread.sleep(3000);
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM", Locale.ENGLISH);

	        // Get current and previous month names
	        String currentMonth = LocalDate.now().format(formatter);
	        String previousMonth = YearMonth.now().minusMonths(1).getMonth()
	                .getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH);

	        // Try both months one by one
	        for (String month : new String[]{currentMonth, previousMonth}) {
	            try {
	                System.out.println("\u001B[36mTrying month: " + month);

	                WebElement element = driver.findElement(By.xpath("(//span[text()='" + month + "']//parent::span)[1]"));
	                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);
	                Thread.sleep(1000);

	                element.click();
	                Thread.sleep(500);
	                element.click();

	                new Actions(driver).doubleClick(element).perform();
	                Thread.sleep(2000); // Allow time for file to start downloading
	                String purple = "\u001B[35m";
	                System.out.println(purple+"Success on month: " + month);
	                break; // Exit loop once clicked successfully

	            } catch (Exception e) {
	                System.err.println("Month not found/clickable: " + month);
	                // Try next month
	            }}

//		} catch (Exception e) {
//
//			System.err.println("Network Issue");
//
	      //  }

	}

	@When("User Download the {string} Current Date File")
	public void user_download_the_current_date_file(String string) throws InterruptedException, AWTException {

		try {

			Thread.sleep(2000);

			LocalDate currentDate = LocalDate.now();

			DateTimeFormatter file = DateTimeFormatter.ofPattern("yyyyMMdd");
			String current = currentDate.format(file);
			String g = "\u001B[35m";
			System.out.println(g+current);

			Thread.sleep(2000);
			JavascriptExecutor js2 = (JavascriptExecutor) driver;

			WebElement element = driver
					.findElement(By.xpath("//span[text()='Margin Detail Report " + current + ".csv']"));

			js2.executeScript("arguments[0].scrollIntoView();", element);

			Thread.sleep(2000);
			String text2 = element.getText();

			if (text2.contains(current)) {

				Thread.sleep(2000);
				WebElement element1 = driver
						.findElement(By.xpath("//span[text()='Margin Detail Report " + current + ".csv']"));

				Actions a = new Actions(driver);

				element1.click();
				Thread.sleep(2000);

				Robot robot = new Robot();

				robot.keyPress(KeyEvent.VK_DOWN);
				robot.keyRelease(KeyEvent.VK_DOWN);
				Thread.sleep(2000);

				a.doubleClick(element1).perform();


			}

			else {

				System.err.println("Today Not Upload File");

			}

			Thread.sleep(3000);

		} catch (Exception e) {

			System.out.println("Network Issue");

		}

	}

	@When("User Download the {string} Previous Date File")
	public void user_download_the_previous_date_file(String string) throws InterruptedException {

		try {

			List<WebElement> elements = driver.findElements(By.xpath("//span[contains(text(),'" + string + "')]"));

			if (!elements.isEmpty()) {
				WebElement lastElement = elements.get(elements.size() - 1);

				String text = lastElement.getText();
				String g = "\u001B[35m";
				System.out.println(g+text);

				Thread.sleep(2000);
				Actions actions = new Actions(driver);
				actions.doubleClick(lastElement).perform();

				

			} else {
				System.out.println("No File found.");
			}

			Thread.sleep(3000);

		} catch (Exception e) {

			System.out.println("Network Issue");

		}

		Thread.sleep(2000);
	}

	@When("User Download the {string} Current Date Files")
	public void user_download_the_current_date_files(String string) throws InterruptedException, AWTException {

		try {

			LocalDate currentDate = LocalDate.now();

			DateTimeFormatter file = DateTimeFormatter.ofPattern("yyyyMMdd");
			String current = currentDate.format(file);
			System.out.println(current);

//			Thread.sleep(2000);
			JavascriptExecutor js9 = (JavascriptExecutor) driver;
//			 js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
//			 Thread.sleep(2000);

			Thread.sleep(2000);

			WebElement element = driver.findElement(By.xpath("(//span[text()='Time']//parent::span)[1]"));

			Actions d = new Actions(driver);

			d.moveToElement(element).perform();
			Thread.sleep(2000);
			driver.findElement(By.xpath("(//span[text()='Time']//parent::span)[1]")).click();
			driver.findElement(By.xpath("(//span[text()='Time']//parent::span)[1]")).click();

			Thread.sleep(2000);
			WebElement element1 = driver.findElement(By.xpath("(((//span[contains(text(),'MCXRPF-" + current
					+ "-')])[1]//ancestor::span)[9]//following-sibling::span)[3]"));

			Thread.sleep(2000);
			js9.executeScript("arguments[0].scrollIntoView();", element1);
			Thread.sleep(2000);

			String text = element1.getText();

			Thread.sleep(2000);
			LocalDate currentDate1 = LocalDate.now();

			Thread.sleep(2000);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
			String date = currentDate1.format(formatter);

			if (text.contains(date)) {

				List<WebElement> allFiles = driver
						.findElements(By.xpath("//span[contains(text(),'MCXRPF-" + current + "-')]"));

				// 6. Click each file link from 01 to last
				for (WebElement file1 : allFiles) {
					String fileName = file1.getText();
					if (fileName.contains("MCXRPF-" + current + "-") && fileName.endsWith("01-I.spn")) {

						Actions a = new Actions(driver);
						Thread.sleep(2000);

						a.doubleClick(file1).perform();

						// file1.click(); // click to download
						Thread.sleep(2000); // wait for download to start

						String text2 = file1.getText();
						String g = "\u001B[35m";
						System.out.println(g+text2);

						Thread.sleep(1000);

						//System.err.println("The File is successfully Downloading");
					}
				}

//				Thread.sleep(2000);
//				WebElement element11 = driver
//						.findElement(By.xpath("(//span[contains(text(),'" + string + "-" + current + "-')])[1]"));
//
//				Actions a = new Actions(driver);
//				Thread.sleep(2000);
//
//				JavascriptExecutor js1 = (JavascriptExecutor) driver;
//				Thread.sleep(2000);
//				js1.executeScript("arguments[0].scrollIntoView();", element11);
//				Thread.sleep(2000);
//
//				element11.click();
//				Thread.sleep(2000);
//
//				a.doubleClick(element11).perform();
//
//				Thread.sleep(2000);
//				System.err.println("The File is successfully Downloading");

			}

			else {

				System.err.println("Today Not Upload File");

			}

			Thread.sleep(3000);

		} catch (Exception e) {

			System.out.println("Network Issue");

		}

		Thread.sleep(4000);

		// driver.close();

	}

	@When("User Download This {string} Current Date File")
	public void user_download_this_current_date_file(String string) throws InterruptedException {

		try {

			Thread.sleep(2000);
			LocalDate currentDate = LocalDate.now();

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
			String date = currentDate.format(formatter);
			String g = "\u001B[35m";
			System.out.println(g+date);

			Thread.sleep(2000);
			JavascriptExecutor js1 = (JavascriptExecutor) driver;

			WebElement element2 = driver.findElement(By.xpath("//span[text()='MCX_ProductMaster.csv']"));

			js1.executeScript("arguments[0].scrollIntoView();", element2);

			Thread.sleep(2000);
			WebElement element = driver.findElement(
					By.xpath("((//span[text()='" + string + "']//ancestor::span)[9]//following-sibling::span)[5]"));

			String text = element.getText();
			System.out.println(text);

			// Step 3: Parse input string to LocalDate
			LocalDate originalDate = LocalDate.parse(date, formatter);

			// Step 4: Subtract 2 days
			LocalDate updatedDate = originalDate.minusDays(2);
			String last = updatedDate.format(formatter);

			Thread.sleep(2000);
			if (text.contains(date)) {

				WebElement element1 = driver.findElement(By.xpath("//span[text()='" + string + "']"));

				Actions a = new Actions(driver);

				element1.click();
				Thread.sleep(2000);

				Robot robot = new Robot();

				robot.keyPress(KeyEvent.VK_DOWN);
				robot.keyRelease(KeyEvent.VK_DOWN);
				Thread.sleep(2000);

				a.doubleClick(element).perform();

				Thread.sleep(2000);
				//System.err.println("The File is successfully Downloading");

			}

			else if (text.contains(last)) {

				WebElement element1 = driver.findElement(By.xpath("//span[text()='" + string + "']"));

				Actions a = new Actions(driver);

				element1.click();
				Thread.sleep(2000);

				Robot robot = new Robot();

				robot.keyPress(KeyEvent.VK_DOWN);
				robot.keyRelease(KeyEvent.VK_DOWN);
				Thread.sleep(2000);

				a.doubleClick(element).perform();
				System.out.println(last);
				Thread.sleep(2000);
				//System.err.println("The File is successfully Downloading");

			}

			else {

				System.err.println("Today Not Upload File");

			}

			Thread.sleep(3000);

		} catch (Exception e) {

			System.out.println("Network Issue");

		}

		Thread.sleep(2000);

	}
	
	@When("User Share The File {string} To Server")
	public void user_share_the_file_to_server(String string) throws InterruptedException, AWTException, HeadlessException, UnsupportedFlavorException, IOException {
	   
		Thread.sleep(2000);
		
		try {
			
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			
            Robot robot=new Robot();
			
            robot.keyPress(KeyEvent.VK_WINDOWS);   
            robot.keyPress(KeyEvent.VK_R);      

            Thread.sleep(500);
            robot.keyRelease(KeyEvent.VK_R);
            robot.keyRelease(KeyEvent.VK_WINDOWS);
			
            Thread.sleep(2000);
            
            
            robot.keyPress(KeyEvent.VK_RIGHT);
            robot.keyRelease(KeyEvent.VK_RIGHT);

            Thread.sleep(500);

            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_A);

            Thread.sleep(500);
              
            robot.keyRelease(KeyEvent.VK_A);
            robot.keyRelease(KeyEvent.VK_CONTROL);

             
            Thread.sleep(1000);

             
            robot.keyPress(KeyEvent.VK_C);
            robot.keyRelease(KeyEvent.VK_C);
            Thread.sleep(500);
            robot.keyPress(KeyEvent.VK_M);
            robot.keyRelease(KeyEvent.VK_M);
            Thread.sleep(500);
            robot.keyPress(KeyEvent.VK_D);
            robot.keyRelease(KeyEvent.VK_D);

            Thread.sleep(1000);

            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            
            Thread.sleep(2000);
            
            String command = "cd Downloads\\FTP-exe";
            StringSelection selection = new StringSelection(command);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);

            Thread.sleep(1000); 

            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);

            Thread.sleep(2000);  
            
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            
            Thread.sleep(2000);
            
            
            
            switch (string) {
            
			case "Bhavcopy":
				
				Thread.sleep(1000);
				
				    String command1 = "FTP-Test.exe \"103.217.66.206\" 65500 navia Navia@#6754 \"D:\\Project\\RMS\\MCX_Files\\File1\\Bhavcopy.csv\" /test/Bhavcopy.csv";
		            StringSelection selection1 = new StringSelection(command1);
		            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection1, null);

		            Thread.sleep(1000);  

		            robot.keyPress(KeyEvent.VK_CONTROL);
		            robot.keyPress(KeyEvent.VK_V);
		            robot.keyRelease(KeyEvent.VK_V);
		            robot.keyRelease(KeyEvent.VK_CONTROL);

		            Thread.sleep(2000);  

		            robot.keyPress(KeyEvent.VK_ENTER);
		            robot.keyRelease(KeyEvent.VK_ENTER);
		            
		            Thread.sleep(10000);
		            robot.keyPress(KeyEvent.VK_CONTROL);
		            robot.keyPress(KeyEvent.VK_ALT);
		            robot.keyPress(KeyEvent.VK_A);
		            robot.keyRelease(KeyEvent.VK_A);
		            robot.keyRelease(KeyEvent.VK_ALT);
		            robot.keyRelease(KeyEvent.VK_CONTROL);

		            Thread.sleep(1000);

		            robot.keyPress(KeyEvent.VK_CONTROL);
		            robot.keyPress(KeyEvent.VK_C);
		            robot.keyRelease(KeyEvent.VK_C);
		            robot.keyRelease(KeyEvent.VK_CONTROL);

		            Thread.sleep(1000); 
		            
		            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		            Transferable contents = clipboard.getContents(null);

		            String name = ""; 

		            if (contents != null && contents.isDataFlavorSupported(DataFlavor.stringFlavor)) {
		                name = (String) contents.getTransferData(DataFlavor.stringFlavor);
		            }


		            Thread.sleep(2000);
		            
		            if (name.contains("Upload status: Fail")) {
		            	
		            	System.err.println("Upload status: Fail");
						
					}
		            else if (name.contains("Upload status: Success")) {
		            	
		            	String b = "\u001B[34m";
						
		            	System.out.println(b+"Upload status: Success");
		            	
					} 
		            
		            else{
		            	
		            	getScreenshot(string);
		            	Thread.sleep(2000);
		            	
		            }
		            
		            Thread.sleep(2000);
		            String command2 = "Exit";
		            StringSelection selection2 = new StringSelection(command2);
		            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection2, null);

		            Thread.sleep(1000);

		            robot.keyPress(KeyEvent.VK_CONTROL);
		            robot.keyPress(KeyEvent.VK_V);
		            robot.keyRelease(KeyEvent.VK_V);
		            robot.keyRelease(KeyEvent.VK_CONTROL);

		            Thread.sleep(2000); 

		            robot.keyPress(KeyEvent.VK_ENTER);
		            robot.keyRelease(KeyEvent.VK_ENTER);
		            
		            Thread.sleep(2000);
		            
				break;
				
				
              case "Margin":
				
				Thread.sleep(1000);
				
				    String command11 = "FTP-Test.exe \"103.217.66.206\" 65500 navia Navia@#6754 \"D:\\Project\\RMS\\MCX_Files\\File3\\MarginDetailReport.csv\" /test/MarginDetailReport.csv";
		            StringSelection selection11 = new StringSelection(command11);
		            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection11, null);

		            Thread.sleep(1000);  

		            robot.keyPress(KeyEvent.VK_CONTROL);
		            robot.keyPress(KeyEvent.VK_V);
		            robot.keyRelease(KeyEvent.VK_V);
		            robot.keyRelease(KeyEvent.VK_CONTROL);

		            Thread.sleep(2000);  

		            robot.keyPress(KeyEvent.VK_ENTER);
		            robot.keyRelease(KeyEvent.VK_ENTER);
		            
		            Thread.sleep(10000);
		            robot.keyPress(KeyEvent.VK_CONTROL);
		            robot.keyPress(KeyEvent.VK_ALT);
		            robot.keyPress(KeyEvent.VK_A);
		            robot.keyRelease(KeyEvent.VK_A);
		            robot.keyRelease(KeyEvent.VK_ALT);
		            robot.keyRelease(KeyEvent.VK_CONTROL);

		            Thread.sleep(1000);

		            robot.keyPress(KeyEvent.VK_CONTROL);
		            robot.keyPress(KeyEvent.VK_C);
		            robot.keyRelease(KeyEvent.VK_C);
		            robot.keyRelease(KeyEvent.VK_CONTROL);

		            Thread.sleep(1000); 
		            
		            Clipboard clipboard1 = Toolkit.getDefaultToolkit().getSystemClipboard();
		            Transferable contents1 = clipboard1.getContents(null);

		            String name1 = ""; 

		            if (contents1 != null && contents1.isDataFlavorSupported(DataFlavor.stringFlavor)) {
		                name1 = (String) contents1.getTransferData(DataFlavor.stringFlavor);
		            }


		            Thread.sleep(2000);
		            
		            if (name1.contains("Upload status: Fail")) {
		            	
		            	System.err.println("Upload status: Fail");
						
					}
		            else if (name1.contains("Upload status: Success")) {
		            	
		            	String b = "\u001B[34m";
						
		            	System.out.println(b+"Upload status: Success");
		            	
					} 
		            
		            else{
		            	
		            	getScreenshot(string);
		            	Thread.sleep(2000);
		            }
		            Thread.sleep(2000);
		            String command21 = "Exit";
		            StringSelection selection21 = new StringSelection(command21);
		            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection21, null);

		            Thread.sleep(1000);

		            robot.keyPress(KeyEvent.VK_CONTROL);
		            robot.keyPress(KeyEvent.VK_V);
		            robot.keyRelease(KeyEvent.VK_V);
		            robot.keyRelease(KeyEvent.VK_CONTROL);

		            Thread.sleep(2000); 

		            robot.keyPress(KeyEvent.VK_ENTER);
		            robot.keyRelease(KeyEvent.VK_ENTER);
		            
		            Thread.sleep(2000);
		            
				break;
				
              case "MCXScrips":
  				
  				Thread.sleep(1000);
  				
  				    String command111 = "FTP-Test.exe \"103.217.66.206\" 65500 navia Navia@#6754 \"D:\\Project\\RMS\\MCX_Files\\File2\\MCXScrips.bcp\" /test/MCXScrips.bcp";
  		            StringSelection selection111 = new StringSelection(command111);
  		            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection111, null);

  		            Thread.sleep(1000);  

  		            robot.keyPress(KeyEvent.VK_CONTROL);
  		            robot.keyPress(KeyEvent.VK_V);
  		            robot.keyRelease(KeyEvent.VK_V);
  		            robot.keyRelease(KeyEvent.VK_CONTROL);

  		            Thread.sleep(2000);  

  		            robot.keyPress(KeyEvent.VK_ENTER);
  		            robot.keyRelease(KeyEvent.VK_ENTER);
  		            
  		            Thread.sleep(15000);
  		            robot.keyPress(KeyEvent.VK_CONTROL);
  		            robot.keyPress(KeyEvent.VK_ALT);
  		            robot.keyPress(KeyEvent.VK_A);
  		            robot.keyRelease(KeyEvent.VK_A);
  		            robot.keyRelease(KeyEvent.VK_ALT);
  		            robot.keyRelease(KeyEvent.VK_CONTROL);

  		            Thread.sleep(1000);

  		            robot.keyPress(KeyEvent.VK_CONTROL);
  		            robot.keyPress(KeyEvent.VK_C);
  		            robot.keyRelease(KeyEvent.VK_C);
  		            robot.keyRelease(KeyEvent.VK_CONTROL);

  		            Thread.sleep(1000); 
  		            
  		            Clipboard clipboard11 = Toolkit.getDefaultToolkit().getSystemClipboard();
  		            Transferable contents11 = clipboard11.getContents(null);

  		            String name11 = ""; 

  		            if (contents11 != null && contents11.isDataFlavorSupported(DataFlavor.stringFlavor)) {
  		                name11 = (String) contents11.getTransferData(DataFlavor.stringFlavor);
  		            }


  		            Thread.sleep(2000);
  		            
  		            if (name11.contains("Upload status: Fail")) {
  		            	
  		            	System.err.println("Upload status: Fail");
  						
  					}
  		            else if (name11.contains("Upload status: Success")) {
  		            	
  		            	String b = "\u001B[34m";
  						
  		            	System.out.println(b+"Upload status: Success");
  		            	
  					} 
  		            
  		            else{
  		            	
  		            	getScreenshot(string);
  		            	Thread.sleep(2000);
  		            }
  		          Thread.sleep(2000);
  		            String command211 = "Exit";
  		            StringSelection selection211 = new StringSelection(command211);
  		            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection211, null);

  		            Thread.sleep(1000);

  		            robot.keyPress(KeyEvent.VK_CONTROL);
  		            robot.keyPress(KeyEvent.VK_V);
  		            robot.keyRelease(KeyEvent.VK_V);
  		            robot.keyRelease(KeyEvent.VK_CONTROL);

  		            Thread.sleep(2000); 

  		            robot.keyPress(KeyEvent.VK_ENTER);
  		            robot.keyRelease(KeyEvent.VK_ENTER);
  		            
  		            Thread.sleep(2000);
  		            
  				break;
  				
              case "Bhavcopy_MCX":
    				
    				Thread.sleep(1000);
    				
    				    String command1111 = "FTP-Test.exe \"103.217.66.206\" 65500 navia Navia@#6754 \"D:\\Project\\RMS\\MCX_Files\\File4\\BhavcopyMCX.csv\" /test/BhavcopyMCX.csv";
    		            StringSelection selection1111 = new StringSelection(command1111);
    		            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection1111, null);

    		            Thread.sleep(1000);  

    		            robot.keyPress(KeyEvent.VK_CONTROL);
    		            robot.keyPress(KeyEvent.VK_V);
    		            robot.keyRelease(KeyEvent.VK_V);
    		            robot.keyRelease(KeyEvent.VK_CONTROL);

    		            Thread.sleep(2000);  

    		            robot.keyPress(KeyEvent.VK_ENTER);
    		            robot.keyRelease(KeyEvent.VK_ENTER);
    		            
    		            Thread.sleep(10000);
    		            robot.keyPress(KeyEvent.VK_CONTROL);
    		            robot.keyPress(KeyEvent.VK_ALT);
    		            robot.keyPress(KeyEvent.VK_A);
    		            robot.keyRelease(KeyEvent.VK_A);
    		            robot.keyRelease(KeyEvent.VK_ALT);
    		            robot.keyRelease(KeyEvent.VK_CONTROL);

    		            Thread.sleep(1000);

    		            robot.keyPress(KeyEvent.VK_CONTROL);
    		            robot.keyPress(KeyEvent.VK_C);
    		            robot.keyRelease(KeyEvent.VK_C);
    		            robot.keyRelease(KeyEvent.VK_CONTROL);

    		            Thread.sleep(1000); 
    		            
    		            Clipboard clipboard3 = Toolkit.getDefaultToolkit().getSystemClipboard();
    		            Transferable contents111 = clipboard3.getContents(null);

    		            String name111 = ""; 

    		            if (contents111 != null && contents111.isDataFlavorSupported(DataFlavor.stringFlavor)) {
    		                name111 = (String) contents111.getTransferData(DataFlavor.stringFlavor);
    		            }


    		            Thread.sleep(2000);
    		            
    		            if (name111.contains("Upload status: Fail")) {
    		            	
    		            	System.err.println("Upload status: Fail");
    						
    					}
    		            else if (name111.contains("Upload status: Success")) {
    		            	
    		            	String b = "\u001B[34m";
    						
    		            	System.out.println(b+"Upload status: Success");
    		            	
    					} 
    		            
    		            else{
    		            	
    		            	getScreenshot(string);
    		            	Thread.sleep(2000);
    		            }
    		            Thread.sleep(2000);
    		            String command2111 = "Exit";
    		            StringSelection selection2111 = new StringSelection(command2111);
    		            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection2111, null);

    		            Thread.sleep(1000);

    		            robot.keyPress(KeyEvent.VK_CONTROL);
    		            robot.keyPress(KeyEvent.VK_V);
    		            robot.keyRelease(KeyEvent.VK_V);
    		            robot.keyRelease(KeyEvent.VK_CONTROL);

    		            Thread.sleep(2000); 

    		            robot.keyPress(KeyEvent.VK_ENTER);
    		            robot.keyRelease(KeyEvent.VK_ENTER);
    		            
    		            Thread.sleep(2000);
    		            
    				break;
    				
              case "MCX_ProductMaster":
  				
  				Thread.sleep(1000);
  				
  				    String command11111 = "FTP-Test.exe \"103.217.66.206\" 65500 navia Navia@#6754 \"D:\\Project\\RMS\\MCX_Files\\File6\\MCX_ProductMaster.csv\" /test/MCX_ProductMaster.csv";
  		            StringSelection selection11111 = new StringSelection(command11111);
  		            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection11111, null);

  		            Thread.sleep(1000);  

  		            robot.keyPress(KeyEvent.VK_CONTROL);
  		            robot.keyPress(KeyEvent.VK_V);
  		            robot.keyRelease(KeyEvent.VK_V);
  		            robot.keyRelease(KeyEvent.VK_CONTROL);

  		            Thread.sleep(2000);  

  		            robot.keyPress(KeyEvent.VK_ENTER);
  		            robot.keyRelease(KeyEvent.VK_ENTER);
  		            
  		            Thread.sleep(10000);
  		            robot.keyPress(KeyEvent.VK_CONTROL);
  		            robot.keyPress(KeyEvent.VK_ALT);
  		            robot.keyPress(KeyEvent.VK_A);
  		            robot.keyRelease(KeyEvent.VK_A);
  		            robot.keyRelease(KeyEvent.VK_ALT);
  		            robot.keyRelease(KeyEvent.VK_CONTROL);

  		            Thread.sleep(1000);

  		            robot.keyPress(KeyEvent.VK_CONTROL);
  		            robot.keyPress(KeyEvent.VK_C);
  		            robot.keyRelease(KeyEvent.VK_C);
  		            robot.keyRelease(KeyEvent.VK_CONTROL);

  		            Thread.sleep(1000); 
  		            
  		            Clipboard clipboard31 = Toolkit.getDefaultToolkit().getSystemClipboard();
  		            Transferable contents1111 = clipboard31.getContents(null);

  		            String name1111 = ""; 

  		            if (contents1111 != null && contents1111.isDataFlavorSupported(DataFlavor.stringFlavor)) {
  		                name1111 = (String) contents1111.getTransferData(DataFlavor.stringFlavor);
  		            }


  		            Thread.sleep(2000);
  		            
  		            if (name1111.contains("Upload status: Fail")) {
  		            	
  		            	System.err.println("Upload status: Fail");
  						
  					}
  		            else if (name1111.contains("Upload status: Success")) {
  		            	
  		            	String b = "\u001B[34m";
  						
  		            	System.out.println(b+"Upload status: Success");
  		            	
  					} 
  		            
  		            else{
  		            	
  		            	getScreenshot(string);
  		            	Thread.sleep(2000);
  		            }
  		          Thread.sleep(2000);
  		            String command21111 = "Exit";
  		            StringSelection selection21111 = new StringSelection(command21111);
  		            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection21111, null);

  		            Thread.sleep(1000);

  		            robot.keyPress(KeyEvent.VK_CONTROL);
  		            robot.keyPress(KeyEvent.VK_V);
  		            robot.keyRelease(KeyEvent.VK_V);
  		            robot.keyRelease(KeyEvent.VK_CONTROL);

  		            Thread.sleep(2000); 

  		            robot.keyPress(KeyEvent.VK_ENTER);
  		            robot.keyRelease(KeyEvent.VK_ENTER);
  		            
  		            Thread.sleep(2000);
  		            
  				break;
  				
              case "MCXRPF":
    				
    				Thread.sleep(1000);
    				
    				    String command111111 = "FTP-Test.exe \"103.217.66.206\" 65500 navia Navia@#6754 \"D:\\Project\\RMS\\MCX_Files\\File5\\MCXRPF.spn\" /test/MCXRPF.spn";
    		            StringSelection selection111111 = new StringSelection(command111111);
    		            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection111111, null);

    		            Thread.sleep(1000);  

    		            robot.keyPress(KeyEvent.VK_CONTROL);
    		            robot.keyPress(KeyEvent.VK_V);
    		            robot.keyRelease(KeyEvent.VK_V);
    		            robot.keyRelease(KeyEvent.VK_CONTROL);

    		            Thread.sleep(2000);  

    		            robot.keyPress(KeyEvent.VK_ENTER);
    		            robot.keyRelease(KeyEvent.VK_ENTER);
    		            
    		            Thread.sleep(15000);
    		            robot.keyPress(KeyEvent.VK_CONTROL);
    		            robot.keyPress(KeyEvent.VK_ALT);
    		            robot.keyPress(KeyEvent.VK_A);
    		            robot.keyRelease(KeyEvent.VK_A);
    		            robot.keyRelease(KeyEvent.VK_ALT);
    		            robot.keyRelease(KeyEvent.VK_CONTROL);

    		            Thread.sleep(1000);

    		            robot.keyPress(KeyEvent.VK_CONTROL);
    		            robot.keyPress(KeyEvent.VK_C);
    		            robot.keyRelease(KeyEvent.VK_C);
    		            robot.keyRelease(KeyEvent.VK_CONTROL);

    		            Thread.sleep(1000); 
    		            
    		            Clipboard clipboard311 = Toolkit.getDefaultToolkit().getSystemClipboard();
    		            Transferable contents11111 = clipboard311.getContents(null);

    		            String name11111 = ""; 

    		            if (contents11111 != null && contents11111.isDataFlavorSupported(DataFlavor.stringFlavor)) {
    		                name11111 = (String) contents11111.getTransferData(DataFlavor.stringFlavor);
    		            }


    		            Thread.sleep(2000);
    		            
    		            if (name11111.contains("Upload status: Fail")) {
    		            	
    		            	System.err.println("Upload status: Fail");
    						
    					}
    		            else if (name11111.contains("Upload status: Success")) {
    		            	
    		            	String b = "\u001B[34m";
    						
    		            	System.out.println(b+"Upload status: Success");
    		            	
    					} 
    		            
    		            else{
    		            	
    		            	getScreenshot(string);
    		            	Thread.sleep(2000);
    		            }
    		            Thread.sleep(2000);
    		            String command211111 = "Exit";
    		            StringSelection selection211111 = new StringSelection(command211111);
    		            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection211111, null);

    		            Thread.sleep(1000);

    		            robot.keyPress(KeyEvent.VK_CONTROL);
    		            robot.keyPress(KeyEvent.VK_V);
    		            robot.keyRelease(KeyEvent.VK_V);
    		            robot.keyRelease(KeyEvent.VK_CONTROL);

    		            Thread.sleep(2000); 

    		            robot.keyPress(KeyEvent.VK_ENTER);
    		            robot.keyRelease(KeyEvent.VK_ENTER);
    		            
    		            Thread.sleep(2000);
    		            
    				break;

			default:
				
				System.err.println("Invalid Your File");
				
				break;
			}
            
            Thread.sleep(2000);
            
           
			
		} catch (Exception e) {
			
			System.err.println("File Not Download and Server Push");
			
		}
		
		Thread.sleep(2000);
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
